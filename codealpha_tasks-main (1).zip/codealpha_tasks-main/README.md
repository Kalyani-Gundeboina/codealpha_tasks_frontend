# Tasks for Frontend Development Internship at [CodeAlpha](https://www.linkedin.com/company/codealpha/)
### Duration: 15/jul/2024 to 15/Aug/2024

## Task 1: Image Gallery -> [Here](https://github.com/Kaameshwar-K/codealpha_tasks/tree/main/Task1_Image%20Gallery)
## Task 2: Calculator -> [Here](https://github.com/Kaameshwar-K/codealpha_tasks/tree/main/Task2_Calculator)
## Task 4: Music Player -> [Here](https://github.com/Kaameshwar-K/codealpha_tasks/tree/main/Task4_Music%20Player)

*i have made the task numbering as per the task pdf provided*
